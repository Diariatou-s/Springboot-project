package com.examen.intermediate.Service.Implementations;

import com.examen.intermediate.DataTransfers.Objects.CoDto;
import com.examen.intermediate.DataTransfers.Objects.FaDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.InputOutputs.Entities.CoEntity;
import com.examen.intermediate.InputOutputs.Entities.FaEntity;
import com.examen.intermediate.InputOutputs.Entities.UtEntity;
import com.examen.intermediate.InputOutputs.Repositories.CoRepo;
import com.examen.intermediate.Service.CoService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class CoServiceImpl implements CoService {

    @Autowired
    CoRepo coRepo;


    @Override
    public CoDto addCo(CoDto co) {
        CoEntity coEntity = new CoEntity();
        BeanUtils.copyProperties(co, coEntity);

        CoEntity newComment = coRepo.save(coEntity);

        CoDto returnValue = new CoDto();
        BeanUtils.copyProperties(newComment, returnValue);

        return returnValue;
    }

    @Override
    public List<CoDto> allCoByAr(String articleId) {
        List<CoDto> returnValue = new ArrayList<>();

        List<CoEntity> allCo = coRepo.findAll();
        List<CoEntity> allCoByArticle = new LinkedList<>();

        for(int i=0;i<allCo.size();i++){

            if(allCo.get(i).getArticleId().equals(articleId)){

                allCoByArticle.add(allCo.get(i));
            }
        }
        for (CoEntity coEntity : allCoByArticle) {
            CoDto coDto = new CoDto();
            BeanUtils.copyProperties(coEntity, coDto);
            returnValue.add(coDto);
        }
        return returnValue;
    }

    @Override
    public CoDto addLike(Long id) {
        CoDto returnValue = new CoDto();

        CoEntity coEntity = coRepo.getById(id);

        int newNmbLike = coEntity.getNmb_likes() + 1;
        coEntity.setNmb_likes(newNmbLike);

        CoEntity updatedCo = coRepo.save(coEntity);
        BeanUtils.copyProperties(updatedCo, returnValue);

        return returnValue;
    }

    @Override
    public CoDto suppLike(Long id) {
        CoDto returnValue = new CoDto();

        CoEntity coEntity = coRepo.getById(id);

        int newNmbLike = coEntity.getNmb_likes() - 1;
        coEntity.setNmb_likes(newNmbLike);

        CoEntity updatedCo = coRepo.save(coEntity);
        BeanUtils.copyProperties(updatedCo, returnValue);

        return returnValue;
    }

    @Override
    public CoDto updateCo(Long id, CoDto co) {
        CoDto returnValue = new CoDto();

        CoEntity coEntity = coRepo.findById(id).orElseThrow();
        coEntity.setTexte(co.getTexte());

        CoEntity updatedCo = coRepo.save(coEntity);
        BeanUtils.copyProperties(updatedCo, returnValue);

        return returnValue;
    }

    @Override
    public CoDto getCoById(Long id) {
        CoDto returnValue = new CoDto();

        CoEntity coEntity = coRepo.getById(id);
        BeanUtils.copyProperties(coEntity, returnValue);

        return returnValue;
    }

    @Override
    public void deleteCoById(Long id) {
        CoEntity coEntity = coRepo.getById(id);

        coRepo.delete(coEntity);
    }
}
