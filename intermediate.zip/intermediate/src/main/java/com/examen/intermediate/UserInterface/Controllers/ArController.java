package com.examen.intermediate.UserInterface.Controllers;

import com.examen.intermediate.DataTransfers.Objects.ArDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.Service.ArService;
import com.examen.intermediate.UserInterface.Model.Request.ArRequest;
import com.examen.intermediate.UserInterface.Model.Request.UtRequest;
import com.examen.intermediate.UserInterface.Model.Response.*;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("ar")
public class ArController {

    @Autowired
    ArService arService;

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @PostMapping
    public ArRest addAr(@RequestBody ArRequest ar) throws Exception {
        ArRest returnValue = new ArRest();
        ArDto arDto = new ArDto();

        BeanUtils.copyProperties(ar, arDto);

        ArDto createdAr = arService.addAr(arDto);
        BeanUtils.copyProperties(createdAr, returnValue);

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping("/author/{id}")
    public List<ArRest> getArByAuthor(@PathVariable("id") String auteurId) {
        List<ArRest> returnValue = new ArrayList<>();

        List<ArDto> articles = arService.getAllArByAuthor(auteurId);

        for (ArDto arDto : articles) {
            ArRest arModel = new ArRest();
            BeanUtils.copyProperties(arDto, arModel);
            returnValue.add(arModel);
        }

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping("/topic/{id}")
    public List<ArRest> getArByTopic(@PathVariable("id") Long categorieId) {
        List<ArRest> returnValue = new ArrayList<>();

        List<ArDto> articles = arService.getAllArByTopic(categorieId);

        for (ArDto arDto : articles) {
            ArRest arModel = new ArRest();
            BeanUtils.copyProperties(arDto, arModel);
            returnValue.add(arModel);
        }

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping
    public List<ArRest> getAllAr(@RequestParam(value="page", defaultValue="1")int page, @RequestParam(value="limit", defaultValue = "15")int limit) {
        List<ArRest> returnValue = new ArrayList<>();

        List<ArDto> articles = arService.getAllAr(page, limit);

        for (ArDto arDto : articles) {
            ArRest arModel = new ArRest();
            BeanUtils.copyProperties(arDto, arModel);
            returnValue.add(arModel);
        }

        return returnValue;
    }

    @PutMapping("/title/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest updateTitre(@PathVariable("id") String id, @RequestBody ArDto ar){
        ArRest returnValue = new ArRest();
        ArDto arDto = new ArDto();

        BeanUtils.copyProperties(ar, arDto);

        ArDto updatedAr = arService.updateTitle(id, arDto);
        BeanUtils.copyProperties(updatedAr, returnValue);

        return returnValue;
    }

    @PutMapping("/body/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest updateBody(@PathVariable("id") String id, @RequestBody ArDto ar){
        ArRest returnValue = new ArRest();
        ArDto arDto = new ArDto();

        BeanUtils.copyProperties(ar, arDto);

        ArDto updatedAr = arService.updateBody(id, arDto);
        BeanUtils.copyProperties(updatedAr, returnValue);

        return returnValue;
    }

    @PutMapping("/addLike/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest addLike(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbLikes = arDto.getNmb_likes() + 1;
        arDto.setNmb_likes(newNmbLikes);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/suppLike/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest suppressLike(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbLikes = arDto.getNmb_likes() - 1;
        arDto.setNmb_likes(newNmbLikes);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/addComment/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest addComment(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbComm = arDto.getNmb_comm() + 1;
        arDto.setNmb_comm(newNmbComm);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/suppComment/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest suppressComment(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbComm = arDto.getNmb_comm() - 1;
        arDto.setNmb_comm(newNmbComm);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/addFavorite/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest addFavorite(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbFav = arDto.getNmb_fav() + 1;
        arDto.setNmb_fav(newNmbFav);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/suppFavorite/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest suppressFavorite(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbFav = arDto.getNmb_fav() - 1;
        arDto.setNmb_fav(newNmbFav);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @PutMapping("/addSeen/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public ArRest addSeen(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto arDto =arService.getArById(id);
        int newNmbVues = arDto.getNmb_vues() + 1;
        arDto.setNmb_vues(newNmbVues);
        ArDto updatedAr = arService.updateAr(arDto);

        BeanUtils.copyProperties(updatedAr,returnValue);

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping("/id/{id}")
    public ArRest getArById(@PathVariable("id") String id){
        ArRest returnValue = new ArRest();

        ArDto ar = arService.getArById(id);
        BeanUtils.copyProperties(ar, returnValue);

        return returnValue;
    }

    @DeleteMapping(path="/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public OperationStatus deleteAr(@PathVariable String id){
        OperationStatus returnValue = new OperationStatus();

        returnValue.setOperationName(OperationName.DELETE.name());
        arService.deleteArById(id);

        returnValue.setOperationResult(OperationResult.SUCCESS.name());

        return returnValue;
    }
}
