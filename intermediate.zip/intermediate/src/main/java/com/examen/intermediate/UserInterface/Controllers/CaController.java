package com.examen.intermediate.UserInterface.Controllers;

import com.examen.intermediate.DataTransfers.Objects.CaDto;
import com.examen.intermediate.DataTransfers.Objects.CoDto;
import com.examen.intermediate.DataTransfers.Objects.FaDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.Service.CaService;
import com.examen.intermediate.Service.CoService;
import com.examen.intermediate.UserInterface.Model.Response.*;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("ca")
public class CaController {

    @Autowired
    CaService caService;

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @PostMapping
    public CaRest addCa(@RequestBody CaRest ca){
        CaRest returnValue = new CaRest();

        CaDto caDto = new CaDto();
        BeanUtils.copyProperties(ca, caDto);

        CaDto newCa = caService.addCa(caDto);
        BeanUtils.copyProperties(newCa, returnValue);

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping
    public List<CaRest> getAllCa(){
        List<CaRest> returnValue = new ArrayList<>();

        List<CaDto> topics = caService.getAllCa();

        for (CaDto caDto : topics) {
            CaRest caModel = new CaRest();
            BeanUtils.copyProperties(caDto, caModel);
            returnValue.add(caModel);
        }

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping(path="/{id}")
    public CaRest getCaById(@PathVariable Long id){
        CaRest returnValue = new CaRest();

        CaDto caDto = caService.getCaById(id);

        BeanUtils.copyProperties(caDto, returnValue);

        return returnValue;
    }

    @DeleteMapping(path="/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public OperationStatus deleteCa(@PathVariable Long id){
        OperationStatus returnValue = new OperationStatus();

        returnValue.setOperationName(OperationName.DELETE.name());

        caService.deleteCa(id);

        returnValue.setOperationResult(OperationResult.SUCCESS.name());

        return returnValue;
    }
}
