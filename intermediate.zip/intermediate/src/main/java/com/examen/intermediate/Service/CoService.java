package com.examen.intermediate.Service;

import com.examen.intermediate.DataTransfers.Objects.CoDto;

import java.util.List;

public interface CoService {
    CoDto addCo(CoDto co);
    List<CoDto> allCoByAr(String articleId);
    CoDto addLike(Long id);
    CoDto suppLike(Long id);
    CoDto getCoById(Long id);
    CoDto updateCo(Long id, CoDto co);
    void deleteCoById(Long id);
}
