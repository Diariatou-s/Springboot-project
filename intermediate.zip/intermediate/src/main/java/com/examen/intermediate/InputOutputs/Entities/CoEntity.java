package com.examen.intermediate.InputOutputs.Entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity(name="commentaire")
public class CoEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false, updatable = false)
    private Long id;

    @Column(nullable = false)
    private String texte;

    @Column(nullable = false)
    private String userId;

    @Column(nullable = false)
    private String articleId;

    @Column(nullable = false)
    private int nmb_likes = 0;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTexte() {
        return texte;
    }

    public void setTexte(String texte) {
        this.texte = texte;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getArticleId() {
        return articleId;
    }

    public void setArticleId(String articleId) {
        this.articleId = articleId;
    }

    public int getNmb_likes() {
        return nmb_likes;
    }

    public void setNmb_likes(int nmb_likes) {
        this.nmb_likes = nmb_likes;
    }
}
