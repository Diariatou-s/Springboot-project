package com.examen.intermediate.DataTransfers.Objects;

import java.io.Serializable;

public class FaDto implements Serializable {

    private Long id;
    private String idUser;
    private String idArticle;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(String idArticle) {
        this.idArticle = idArticle;
    }
}
