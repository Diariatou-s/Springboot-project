package com.examen.intermediate.UserInterface.Model.Response;

public enum OperationResult {
    ERROR, SUCCESS
}
