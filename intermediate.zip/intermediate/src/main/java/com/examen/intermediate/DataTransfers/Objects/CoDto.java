package com.examen.intermediate.DataTransfers.Objects;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

public class CoDto implements Serializable {

    private Long id;
    private String texte;
    private String userId;
    private String articleId;
    private int nmb_likes = 0;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTexte() {
        return texte;
    }

    public void setTexte(String texte) {
        this.texte = texte;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getArticleId() {
        return articleId;
    }

    public void setArticleId(String articleId) {
        this.articleId = articleId;
    }

    public int getNmb_likes() {
        return nmb_likes;
    }

    public void setNmb_likes(int nmb_likes) {
        this.nmb_likes = nmb_likes;
    }
}
