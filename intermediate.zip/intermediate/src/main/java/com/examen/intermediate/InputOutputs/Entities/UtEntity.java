package com.examen.intermediate.InputOutputs.Entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

@Entity(name="utilisateur")
public class UtEntity implements Serializable {

    @Id
    @GeneratedValue
    private long id;

    @Column(nullable = false, unique = true)
    private String userId;

    @Column(nullable = false, length=50)
    private String prenom;

    @Column(nullable = false, length=50)
    private String nom;

    @Column(nullable = false, length=120, unique=true)
    private String email;

    @Column(nullable = false)
    private String encryptedMdp;

    @Column(nullable = false)
    private String bio = "Pas de biographie";

    @Column(nullable = false)
    private int nmb_art_ecrits = 0;

    private String emailVerificationToken;

    @Column(nullable = false)
    private boolean emailVerificationStatus = false;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEncryptedMdp() {
        return encryptedMdp;
    }

    public void setEncryptedMdp(String encryptedMdp) {
        this.encryptedMdp = encryptedMdp;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public int getNmb_art_ecrits() {
        return nmb_art_ecrits;
    }

    public void setNmb_art_ecrits(int nmb_art_ecrits) {
        this.nmb_art_ecrits = nmb_art_ecrits;
    }

    public String getEmailVerificationToken() {
        return emailVerificationToken;
    }

    public void setEmailVerificationToken(String emailVerificationToken) {
        this.emailVerificationToken = emailVerificationToken;
    }

    public boolean isEmailVerificationStatus() {
        return emailVerificationStatus;
    }

    public void setEmailVerificationStatus(boolean emailVerificationStatus) {
        this.emailVerificationStatus = emailVerificationStatus;
    }
}
