package com.examen.intermediate.UserInterface.Controllers;

import com.examen.intermediate.DataTransfers.Objects.FaDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.Service.FaService;
import com.examen.intermediate.UserInterface.Model.Request.UtRequest;
import com.examen.intermediate.UserInterface.Model.Response.*;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("fa")
public class FaController {

    @Autowired
    FaService faService;

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @PostMapping
    public FaRest addFavorite(@RequestBody FaRest fa) throws Exception {
        FaRest returnValue = new FaRest();
        FaDto faDto = new FaDto();

        BeanUtils.copyProperties(fa, faDto);

        FaDto addedFa = faService.addFa(faDto);
        BeanUtils.copyProperties(addedFa, returnValue);

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping(path="/{id}")
    public List<FaRest> getAllFaByUt(@PathVariable String id) {
        List<FaRest> returnValue = new ArrayList<>();

        List<FaDto> favorites = faService.getAllFaByUt(id);

        for (FaDto faDto : favorites) {
            FaRest faModel = new FaRest();
            BeanUtils.copyProperties(faDto, faModel);
            returnValue.add(faModel);
        }

        return returnValue;
    }

    @DeleteMapping(path="/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public OperationStatus deleteFa(@PathVariable Long id){
        OperationStatus returnValue = new OperationStatus();

        returnValue.setOperationName(OperationName.DELETE.name());

        faService.deleteFa(id);

        returnValue.setOperationResult(OperationResult.SUCCESS.name());

        return returnValue;
    }
}
