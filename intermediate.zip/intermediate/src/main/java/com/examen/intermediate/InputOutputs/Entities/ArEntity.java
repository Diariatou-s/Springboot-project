package com.examen.intermediate.InputOutputs.Entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity(name="article")
public class ArEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false, updatable = false)
    private Long id;
    @Column(nullable = false)
    private String articleId;
    @Column(nullable = false)
    private String titre;
    @Column(nullable = false, unique = true)
    private String texte;
    @Column(nullable = false)
    private String auteurId;
    @Column(nullable = false)
    private Date date_creation = new Date();
    @Column(nullable = false)
    private Long categorieId;
    @Column(nullable = false)
    private int nmb_likes = 0;
    @Column(nullable = false)
    private int nmb_comm = 0;
    @Column(nullable = false)
    private int nmb_vues = 0;
    @Column(nullable = false)
    private int nmb_fav = 0;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getArticleId() {
        return articleId;
    }

    public void setArticleId(String articleId) {
        this.articleId = articleId;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getTexte() {
        return texte;
    }

    public void setTexte(String texte) {
        this.texte = texte;
    }

    public String getAuteurId() {
        return auteurId;
    }

    public void setAuteurId(String auteurId) {
        this.auteurId = auteurId;
    }

    public Date getDate_creation() {
        return date_creation;
    }

    public void setDate_creation(Date date_creation) {
        this.date_creation = date_creation;
    }

    public Long getCategorieId() {
        return categorieId;
    }

    public void setCategorieId(Long categorieId) {
        this.categorieId = categorieId;
    }

    public int getNmb_likes() {
        return nmb_likes;
    }

    public void setNmb_likes(int nmb_likes) {
        this.nmb_likes = nmb_likes;
    }

    public int getNmb_comm() {
        return nmb_comm;
    }

    public void setNmb_comm(int nmb_comm) {
        this.nmb_comm = nmb_comm;
    }

    public int getNmb_vues() {
        return nmb_vues;
    }

    public void setNmb_vues(int nmb_vues) {
        this.nmb_vues = nmb_vues;
    }

    public int getNmb_fav() {
        return nmb_fav;
    }

    public void setNmb_fav(int nmb_fav) {
        this.nmb_fav = nmb_fav;
    }
}
