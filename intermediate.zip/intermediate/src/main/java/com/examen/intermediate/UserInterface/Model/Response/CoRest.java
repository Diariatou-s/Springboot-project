package com.examen.intermediate.UserInterface.Model.Response;

public class CoRest {

    private String userId;
    private String articleId;
    private String texte;
    private int nmb_likes = 0;

    public String getTexte() {
        return texte;
    }

    public void setTexte(String texte) {
        this.texte = texte;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getArticleId() {
        return articleId;
    }

    public void setArticleId(String articleId) {
        this.articleId = articleId;
    }

    public int getNmb_likes() {
        return nmb_likes;
    }

    public void setNmb_likes(int nmb_likes) {
        this.nmb_likes = nmb_likes;
    }
}
