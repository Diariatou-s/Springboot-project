package com.examen.intermediate.Service;

import com.examen.intermediate.DataTransfers.Objects.CaDto;

import java.util.List;

public interface CaService {
    CaDto addCa(CaDto ca);
    List<CaDto> getAllCa();
    CaDto getCaById(Long id);
    void deleteCa(Long id);
}
