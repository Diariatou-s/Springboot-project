package com.examen.intermediate.Service.Implementations;

import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.InputOutputs.Entities.UtEntity;
import com.examen.intermediate.DataTransfers.Utils;
import com.examen.intermediate.Service.UtService;
import com.examen.intermediate.InputOutputs.Repositories.UtRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UtServiceImpl implements UtService {

    @Autowired
    UtRepo utRepo;

    @Autowired
    Utils utils;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public UtDto createUt(UtDto ut) {
        if(utRepo.findByEmail(ut.getEmail()) != null) throw new RuntimeException("Record already exist");

        UtEntity utEntity = new UtEntity();
        BeanUtils.copyProperties(ut, utEntity);

        String publicUserId = utils.generateUserId(30);

        utEntity.setUserId(publicUserId);
        utEntity.setEncryptedMdp(bCryptPasswordEncoder.encode(ut.getMdp()));

        UtEntity storedUtDetails = utRepo.save(utEntity);

        UtDto returnValue = new UtDto();
        BeanUtils.copyProperties(storedUtDetails, returnValue);

        return returnValue;
    }

    @Override
    public UtDto getUser(String email) {
        UtEntity utEntity = utRepo.findByEmail(email);
        if(utEntity == null) throw new UsernameNotFoundException(email);

        UtDto returnValue = new UtDto();
        BeanUtils.copyProperties(utEntity, returnValue);

        return returnValue;
    }

    @Override
    public UtDto getUserByUserId(String userId) {
        UtDto returnValue = new UtDto();

        UtEntity utEntity = utRepo.findByUserId(userId);
        if(utEntity == null) throw new UsernameNotFoundException(userId);

        BeanUtils.copyProperties(utEntity, returnValue);

        return returnValue;
    }

    @Override
    public UtDto updateUserById(String userId, UtDto utDto) {
        UtDto returnValue = new UtDto();

        UtEntity utEntity = utRepo.findByUserId(userId);
        if(utEntity == null) throw new UsernameNotFoundException(userId);

        utEntity.setPrenom(utDto.getPrenom());
        utEntity.setNom(utDto.getNom());

        UtEntity updatedUt = utRepo.save(utEntity);
        BeanUtils.copyProperties(updatedUt, returnValue);

        return returnValue;
    }

    @Override
    public UtDto updateBio(String userId, UtDto utDto) {
        UtDto returnValue = new UtDto();

        UtEntity utEntity = utRepo.findByUserId(userId);
        if(utEntity == null) throw new UsernameNotFoundException(userId);

        utEntity.setBio(utDto.getBio());

        UtEntity updatedUt = utRepo.save(utEntity);
        BeanUtils.copyProperties(updatedUt, returnValue);

        return returnValue;
    }

    @Override
    public UtDto updateNae(UtDto utDto) {
        UtDto returnValue = new UtDto();

        UtEntity utEntity = new UtEntity();
        BeanUtils.copyProperties(utDto, utEntity);

        UtEntity updatedUt = utRepo.save(utEntity);
        BeanUtils.copyProperties(updatedUt, returnValue);

        return returnValue;
    }

    @Override
    public void deleteUser(String userId) {
        UtEntity utEntity = utRepo.findByUserId(userId);
        if(utEntity == null) throw new UsernameNotFoundException(userId);

        utRepo.delete(utEntity);
    }

    @Override
    public List<UtDto> getUsers(int page, int limit) {
        List<UtDto> returnValue = new ArrayList<>();

        if(page>0) page = page-1;

        Pageable pageableRequest = PageRequest.of(page, limit);

        Page<UtEntity> usersPage = utRepo.findAll(pageableRequest);
        List<UtEntity> users = usersPage.getContent();

        for (UtEntity utEntity : users) {
            UtDto utDto = new UtDto();
            BeanUtils.copyProperties(utEntity, utDto);
            returnValue.add(utDto);
        }

        return returnValue;
    }


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        UtEntity utEntity = utRepo.findByEmail(email);
        if(utEntity == null) throw new UsernameNotFoundException(email);

        return new User(utEntity.getEmail(), utEntity.getEncryptedMdp(), new ArrayList<>());
    }
}
