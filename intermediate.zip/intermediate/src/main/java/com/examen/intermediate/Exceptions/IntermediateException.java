package com.examen.intermediate.Exceptions;

public class IntermediateException extends RuntimeException{

    public IntermediateException(String message){
        super(message);
    }
}
