package com.examen.intermediate.UserInterface.Model.Response;

public class UtRest {

    private String userId;
    private String prenom;
    private String nom;
    private String email;
    private String bio = "Pas de biographie";
    private int nmb_art_ecrits = 0;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public int getNmb_art_ecrits() {
        return nmb_art_ecrits;
    }

    public void setNmb_art_ecrits(int nmb_art_ecrits) {
        this.nmb_art_ecrits = nmb_art_ecrits;
    }
}
