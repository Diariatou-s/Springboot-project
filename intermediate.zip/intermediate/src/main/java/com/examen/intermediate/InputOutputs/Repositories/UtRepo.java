package com.examen.intermediate.InputOutputs.Repositories;

import com.examen.intermediate.InputOutputs.Entities.UtEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UtRepo extends PagingAndSortingRepository<UtEntity,Long> {
    UtEntity findByEmail(String email);
    UtEntity findByUserId(String userId);
}
