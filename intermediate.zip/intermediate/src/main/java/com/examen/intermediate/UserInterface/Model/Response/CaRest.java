package com.examen.intermediate.UserInterface.Model.Response;

import java.io.Serializable;

public class CaRest {

    private String intitule;

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }
}
