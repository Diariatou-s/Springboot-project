package com.examen.intermediate.Service.Implementations;

import com.examen.intermediate.DataTransfers.Objects.CaDto;
import com.examen.intermediate.DataTransfers.Objects.FaDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.InputOutputs.Entities.CaEntity;
import com.examen.intermediate.InputOutputs.Entities.CoEntity;
import com.examen.intermediate.InputOutputs.Entities.FaEntity;
import com.examen.intermediate.InputOutputs.Entities.UtEntity;
import com.examen.intermediate.InputOutputs.Repositories.CaRepo;
import com.examen.intermediate.Service.CaService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CaServiceImpl implements CaService {

    @Autowired
    CaRepo caRepo;

    @Override
    public CaDto addCa(CaDto ca){
        CaEntity caEntity = new CaEntity();
        BeanUtils.copyProperties(ca, caEntity);

        CaEntity newTopic = caRepo.save(caEntity);

        CaDto returnValue = new CaDto();
        BeanUtils.copyProperties(newTopic, returnValue);

        return returnValue;
    }

    @Override
    public List<CaDto> getAllCa() {
        List<CaDto> returnValue = new ArrayList<>();

        List<CaEntity> allCa = caRepo.findAll();

        for (CaEntity caEntity : allCa) {
            CaDto caDto = new CaDto();
            BeanUtils.copyProperties(caEntity, caDto);
            returnValue.add(caDto);
        }

        return returnValue;
    }

    @Override
    public CaDto getCaById(Long id) {
        CaDto returnValue = new CaDto();

        CaEntity caEntity = caRepo.findById(id).orElseThrow();
        BeanUtils.copyProperties(caEntity, returnValue);

        return returnValue;
    }

    @Override
    public void deleteCa(Long id){
        caRepo.deleteById(id);
    }
}
