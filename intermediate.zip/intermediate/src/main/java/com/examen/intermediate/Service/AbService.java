package com.examen.intermediate.Service;

import com.examen.intermediate.DataTransfers.Objects.AbDto;
import com.examen.intermediate.InputOutputs.Entities.AbEntity;
import com.examen.intermediate.UserInterface.Model.Response.AbRest;

import java.util.List;

public interface AbService {
    AbDto addAb(AbDto ab);
    List<AbDto> getAllFollowingsByUt(String id);
    List<AbDto> getAllFollowersByUt(String id);
    List<AbDto> getAllFollowings();
    void deleteAbById(Long id);

}
