package com.examen.intermediate.UserInterface.Controllers;

import com.examen.intermediate.DataTransfers.Objects.ArDto;
import com.examen.intermediate.DataTransfers.Objects.UtDto;
import com.examen.intermediate.Exceptions.IntermediateException;
import com.examen.intermediate.Service.UtService;
import com.examen.intermediate.UserInterface.Model.Request.UtRequest;
import com.examen.intermediate.UserInterface.Model.Response.*;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("ut")
public class UtController {

    @Autowired
    UtService utService;

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping(path="/{id}")
    public UtRest getUser(@PathVariable String id){
        UtRest returnValue = new UtRest();

        UtDto utDto = utService.getUserByUserId(id);

        BeanUtils.copyProperties(utDto, returnValue);

        return returnValue;
    }

    @PostMapping
    public UtRest createUser(@RequestBody UtRequest ut) throws Exception {
        UtRest returnValue = new UtRest();
        UtDto utDto = new UtDto();

        BeanUtils.copyProperties(ut, utDto);

        UtDto createdUt = utService.createUt(utDto);
        BeanUtils.copyProperties(createdUt, returnValue);

        return returnValue;
    }

    @PutMapping("/user/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public UtRest updateUser(@PathVariable("id") String id, @RequestBody UtRequest ut){
        UtRest returnValue = new UtRest();
        UtDto utDto = new UtDto();

        BeanUtils.copyProperties(ut, utDto);

        UtDto updatedUt = utService.updateUserById(id, utDto);
        BeanUtils.copyProperties(updatedUt, returnValue);

        return returnValue;
    }

    @PutMapping("/bio/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public UtRest updateBio(@PathVariable("id") String id, @RequestBody UtDto ut){
        UtRest returnValue = new UtRest();
        UtDto utDto = new UtDto();

        BeanUtils.copyProperties(ut, utDto);

        UtDto updatedUt = utService.updateBio(id, utDto);
        BeanUtils.copyProperties(updatedUt, returnValue);

        return returnValue;
    }

    @PutMapping("/nae/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public UtRest updateNae(@PathVariable("id") String id){
        UtRest returnValue = new UtRest();

        UtDto utDto =utService.getUserByUserId(id);

        int newNmbArtEcrits = utDto.getNmb_art_ecrits() + 1;
        utDto.setNmb_art_ecrits(newNmbArtEcrits);
        UtDto updatedUt = utService.updateNae(utDto);

        BeanUtils.copyProperties(updatedUt,returnValue);

        return returnValue;
    }

    @DeleteMapping(path="/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization", value="${utController.authorizationHeader.description}", paramType="header")
    })
    public OperationStatus deleteUser(@PathVariable String id){
        OperationStatus returnValue = new OperationStatus();

        returnValue.setOperationName(OperationName.DELETE.name());

        utService.deleteUser(id);

        returnValue.setOperationResult(OperationResult.SUCCESS.name());

        return returnValue;
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name="authorization",
                    value="${utController.authorizationHeader.description}", paramType="header")
    })
    @GetMapping
    public List<UtRest> getUsers(@RequestParam(value="page", defaultValue="1")int page, @RequestParam(value="limit", defaultValue = "5")int limit) {
        List<UtRest> returnValue = new ArrayList<>();

        List<UtDto> users = utService.getUsers(page, limit);

        for (UtDto utDto : users) {
            UtRest utModel = new UtRest();
            BeanUtils.copyProperties(utDto, utModel);
            returnValue.add(utModel);
        }

        return returnValue;
    }
}
