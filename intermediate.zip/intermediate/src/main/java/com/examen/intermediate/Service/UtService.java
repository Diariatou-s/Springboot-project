package com.examen.intermediate.Service;

import com.examen.intermediate.DataTransfers.Objects.UtDto;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UtService extends UserDetailsService {
    UtDto createUt(UtDto ut);
    UtDto getUser(String email);
    UtDto getUserByUserId(String userId);
    UtDto updateUserById(String userId, UtDto utDto);
    UtDto updateBio(String userId, UtDto utDto);
    UtDto updateNae(UtDto utDto);
    void deleteUser(String userId);
    List<UtDto> getUsers(int page, int limit);
}
