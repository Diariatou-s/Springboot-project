package com.examen.intermediate.UserInterface.Model.Response;

public class AbRest {

    private String suivantId;
    private String suiviId;

    public String getSuivantId() {
        return suivantId;
    }

    public void setSuivantId(String suivantId) {
        this.suivantId = suivantId;
    }

    public String getSuiviId() {
        return suiviId;
    }

    public void setSuiviId(String suiviId) {
        this.suiviId = suiviId;
    }
}
